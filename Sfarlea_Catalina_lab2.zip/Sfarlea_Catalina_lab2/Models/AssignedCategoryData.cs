﻿namespace Sfarlea_Catalina_lab2.Models
{
    public class AssignedCategoryData
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }

        public bool Assigned { get; set; }
    }
}
